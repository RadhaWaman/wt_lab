from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods
from .forms import BillCalculatorForm
from .models import BillRecord
from decimal import Decimal

def calculate_bill(units):
    """
    Calculate electricity bill based on tiered pricing
    0-50: Rs. 3.50/unit
    51-150: Rs. 4.00/unit
    151-250: Rs. 5.20/unit
    Above 250: Rs. 6.50/unit
    """
    units = Decimal(str(units))
    bill = Decimal('0.00')
    
    if units <= 50:
        bill = units * Decimal('3.50')
    elif units <= 150:
        bill = (50 * Decimal('3.50')) + ((units - 50) * Decimal('4.00'))
    elif units <= 250:
        bill = (50 * Decimal('3.50')) + (100 * Decimal('4.00')) + ((units - 150) * Decimal('5.20'))
    else:
        bill = (50 * Decimal('3.50')) + (100 * Decimal('4.00')) + (100 * Decimal('5.20')) + ((units - 250) * Decimal('6.50'))
    
    return bill


def index(request):
    """Home page showing bill calculator form"""
    form = BillCalculatorForm()
    return render(request, 'calculator/index.html', {'form': form})


def calculate(request):
    """Handle bill calculation"""
    if request.method == 'POST':
        form = BillCalculatorForm(request.POST)
        if form.is_valid():
            customer_name = form.cleaned_data['customer_name']
            units_consumed = form.cleaned_data['units_consumed']
            
            # Calculate the bill
            total_bill = calculate_bill(units_consumed)
            
            # Save to database
            BillRecord.objects.create(
                customer_name=customer_name,
                units_consumed=units_consumed,
                total_bill=total_bill
            )
            
            # Get bill breakdown
            units = Decimal(str(units_consumed))
            breakdown = get_bill_breakdown(units)
            
            context = {
                'form': form,
                'customer_name': customer_name,
                'units_consumed': units_consumed,
                'total_bill': total_bill,
                'breakdown': breakdown,
                'calculated': True
            }
            return render(request, 'calculator/index.html', context)
    else:
        form = BillCalculatorForm()
    
    return render(request, 'calculator/index.html', {'form': form})


def get_bill_breakdown(units):
    """Get detailed breakdown of bill calculation"""
    breakdown = []
    units_decimal = Decimal(str(units))
    
    if units_decimal > 0:
        if units_decimal <= 50:
            breakdown.append({
                'range': '0-50 units',
                'units': units_decimal,
                'rate': Decimal('3.50'),
                'amount': units_decimal * Decimal('3.50')
            })
        else:
            breakdown.append({
                'range': '0-50 units',
                'units': 50,
                'rate': Decimal('3.50'),
                'amount': 50 * Decimal('3.50')
            })
            
            if units_decimal <= 150:
                breakdown.append({
                    'range': '51-150 units',
                    'units': units_decimal - 50,
                    'rate': Decimal('4.00'),
                    'amount': (units_decimal - 50) * Decimal('4.00')
                })
            else:
                breakdown.append({
                    'range': '51-150 units',
                    'units': 100,
                    'rate': Decimal('4.00'),
                    'amount': 100 * Decimal('4.00')
                })
                
                if units_decimal <= 250:
                    breakdown.append({
                        'range': '151-250 units',
                        'units': units_decimal - 150,
                        'rate': Decimal('5.20'),
                        'amount': (units_decimal - 150) * Decimal('5.20')
                    })
                else:
                    breakdown.append({
                        'range': '151-250 units',
                        'units': 100,
                        'rate': Decimal('5.20'),
                        'amount': 100 * Decimal('5.20')
                    })
                    
                    breakdown.append({
                        'range': 'Above 250 units',
                        'units': units_decimal - 250,
                        'rate': Decimal('6.50'),
                        'amount': (units_decimal - 250) * Decimal('6.50')
                    })
    
    return breakdown


def history(request):
    """Display bill history"""
    records = BillRecord.objects.all()
    return render(request, 'calculator/history.html', {'records': records})


def clear_history(request):
    """Clear all bill history"""
    if request.method == 'POST':
        BillRecord.objects.all().delete()
        return redirect('history')
    return redirect('history')
