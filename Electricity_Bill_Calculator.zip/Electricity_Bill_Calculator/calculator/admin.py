from django.contrib import admin
from .models import BillRecord

@admin.register(BillRecord)
class BillRecordAdmin(admin.ModelAdmin):
    list_display = ('customer_name', 'units_consumed', 'total_bill', 'created_at')
    search_fields = ('customer_name',)
    list_filter = ('created_at',)
    ordering = ('-created_at',)
