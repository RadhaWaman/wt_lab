from django.db import models

class BillRecord(models.Model):
    """Model to store bill calculation records"""
    customer_name = models.CharField(max_length=100)
    units_consumed = models.DecimalField(max_digits=10, decimal_places=2)
    total_bill = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.customer_name} - {self.units_consumed} units"

    class Meta:
        ordering = ['-created_at']
