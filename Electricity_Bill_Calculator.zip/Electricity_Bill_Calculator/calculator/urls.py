from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('calculate/', views.calculate, name='calculate'),
    path('history/', views.history, name='history'),
    path('clear-history/', views.clear_history, name='clear_history'),
]
