// Custom JavaScript for Electricity Bill Calculator

$(document).ready(function() {
    console.log('Bill Calculator loaded');
    
    // Form submission handler
    $('#billForm').on('submit', function(e) {
        var customerName = $('#customerName').val().trim();
        var units = $('#unitsConsumed').val().trim();
        
        // Trim inputs
        $('#customerName').val(customerName);
        $('#unitsConsumed').val(units);
        
        // Validate customer name
        if (!customerName) {
            e.preventDefault();
            showError('Please enter a customer name!');
            $('#customerName').focus();
            return false;
        }
        
        if (customerName.length < 2) {
            e.preventDefault();
            showError('Customer name must be at least 2 characters long!');
            $('#customerName').focus();
            return false;
        }
        
        // Validate units
        if (!units) {
            e.preventDefault();
            showError('Please enter units consumed!');
            $('#unitsConsumed').focus();
            return false;
        }
        
        if (isNaN(units) || parseFloat(units) < 0) {
            e.preventDefault();
            showError('Please enter a valid positive number for units!');
            $('#unitsConsumed').focus();
            return false;
        }
        
        // Show loading state
        $(this).find('button[type="submit"]').prop('disabled', true);
        $(this).find('button[type="submit"]').html('<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Calculating...');
    });
    
    // Continue calculation
    window.continueCalculation = function() {
        $('#customerName').val('').focus();
        $('#unitsConsumed').val('');
        $('.results-section').fadeOut(function() {
            $('html, body').animate({
                scrollTop: $('#billForm').offset().top - 100
            }, 300);
        });
    };
    
    // Stop calculation
    window.stopCalculation = function() {
        if (confirm('Are you sure you want to exit the calculator?')) {
            $('.results-section').fadeOut();
            $('#billForm').fadeOut();
            showMessage('Thank you for using Electricity Bill Calculator!', 'success');
        }
    };
    
    // Real-time input validation
    $('#customerName').on('input', function() {
        var value = $(this).val();
        if (value && value.length >= 2) {
            $(this).removeClass('is-invalid');
        }
    });
    
    $('#unitsConsumed').on('input', function() {
        var value = $(this).val();
        if (value && !isNaN(value) && parseFloat(value) >= 0) {
            $(this).removeClass('is-invalid');
        }
    });
    
    // Tab key navigation
    $('#customerName').on('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            $('#unitsConsumed').focus();
        }
    });
    
    $('#unitsConsumed').on('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            $('#billForm').submit();
        }
    });
    
    // Animate results if they exist
    if ($('.results-section').length) {
        animateResults();
    }
    
    // Add animation to history rows
    if ($('.history-row').length) {
        animateHistoryRows();
    }
    
    // Print functionality
    $(document).on('click', '.print-bill', function() {
        window.print();
    });
});

// Function to show error messages
function showError(message) {
    // Remove existing error alert
    $('.error-alert').remove();
    
    // Create error alert
    var errorHTML = '<div class="alert alert-danger alert-dismissible fade show error-alert" role="alert">' +
                    message +
                    '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                    '</div>';
    
    // Insert after form
    $('#billForm').after(errorHTML);
    
    // Scroll to error
    $('html, body').animate({
        scrollTop: $('.error-alert').offset().top - 100
    }, 300);
}

// Function to show success/info messages
function showMessage(message, type) {
    // Remove existing message alert
    $('.message-alert').remove();
    
    var alertClass = 'alert-' + type;
    
    // Create message alert
    var messageHTML = '<div class="alert ' + alertClass + ' alert-dismissible fade show message-alert text-center" role="alert">' +
                    message +
                    '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                    '</div>';
    
    // Insert after form
    $('#billForm').after(messageHTML);
}

// Animate results section
function animateResults() {
    var elements = $('.results-section').find('*');
    
    elements.each(function(index) {
        $(this).css({
            'opacity': '0',
            'animation': 'fadeIn 0.5s ease-in forwards'
        }).css('animation-delay', (index * 0.05) + 's');
    });
}

// Animate history rows
function animateHistoryRows() {
    var rows = $('.history-row');
    
    rows.each(function(index) {
        $(this).css({
            'animation': 'fadeIn 0.4s ease-in forwards'
        }).css('animation-delay', (index * 0.1) + 's');
    });
}

// Utility function to format currency
function formatCurrency(amount) {
    return 'Rs. ' + parseFloat(amount).toFixed(2).replace(/,/g, ',');
}

// Log bill calculation for debugging
function logBillCalculation(units) {
    var rate1 = 3.50;
    var rate2 = 4.00;
    var rate3 = 5.20;
    var rate4 = 6.50;
    
    console.log('Calculating bill for ' + units + ' units:');
    console.log('0-50: ' + Math.min(units, 50) + ' units @ Rs. ' + rate1);
    console.log('51-150: ' + Math.max(0, Math.min(units - 50, 100)) + ' units @ Rs. ' + rate2);
    console.log('151-250: ' + Math.max(0, Math.min(units - 150, 100)) + ' units @ Rs. ' + rate3);
    console.log('250+: ' + Math.max(0, units - 250) + ' units @ Rs. ' + rate4);
}

// Add CSS animation styles dynamically if not present
if (!$('style:contains("fadeIn")').length) {
    $('<style>')
        .text(`
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            
            @keyframes slideUp {
                from {
                    opacity: 0;
                    transform: translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
        `)
        .appendTo('head');
}
