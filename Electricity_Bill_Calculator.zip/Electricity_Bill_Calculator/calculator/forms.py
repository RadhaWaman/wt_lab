from django import forms

class BillCalculatorForm(forms.Form):
    """Form for electricity bill calculation"""
    customer_name = forms.CharField(
        max_length=100,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter customer name',
            'id': 'customerName'
        })
    )
    units_consumed = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        required=True,
        min_value=0,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter units consumed',
            'id': 'unitsConsumed',
            'type': 'text'
        })
    )
